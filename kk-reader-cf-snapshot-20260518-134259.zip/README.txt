# kk-reader Cloudflare Snapshot

Generated: 2026-05-18T13:42:59.733078+00:00
Schema:    1

## ファイル構成

- CF_STATE.json : 集約サマリ(まずこれを読む。メールアドレスは redaction 済み)
- raw/          : Cloudflare API のレスポンス verbatim
                  (raw 配下にはメールアドレスや内部 ID が残る、外部に
                   出すときは内容確認すること)

## 取得セクション(成功/失敗)

- worker_deployments: ok
- worker_settings: ok
- worker_secrets: ok
- kv_keys: ok
- pages_project: ok
- pages_deployments: ok
- access_apps: ok
- access_policies: ok (2 app(s))

## サマリ統計

- Worker deployments (recent): 10
- Pages deployments (in window): 20
  - by trigger: auto=18, manual=2
  - by env:     {'production': 20}
  - by stage:   {'deploy/success': 10, 'queued/idle': 10}
- Access apps: 2
- KV keys total: 169
- KV by prefix: {'<other>': 13, 'article:v2: (stale)': 111, 'article:v3:': 44, 'state:': 1}

## 含まないもの(意図的)

- Worker secrets の値(名前のみ、SYNC_SECRET 等)
- KV values(state:default の中身、article cache の中身)
- Worker のソースコード(repo にある)
- Cloudflare アカウントのメール、課金情報
