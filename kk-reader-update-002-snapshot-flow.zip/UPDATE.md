# 更新内容 — 開発フロー確立

このパッケージで追加・変更されるファイル:

- **`scripts/snapshot.py`** (新規追加) — プロジェクトの状態スナップショットZIPを生成するツール
- **`.gitignore`** (変更) — 生成されたスナップショットZIPとSTATE.jsonを除外する

## 適用方法

Codespacesターミナルで:

```bash
git pull --rebase                                    # 同期
# このZIPをCodespacesにドラッグ&ドロップ
unzip -o kk-reader-update-*.zip                      # 展開
rm kk-reader-update-*.zip UPDATE.md                  # 後片付け
git add -A && git status                             # 確認
git commit -m "Add: snapshot generation tool"
git push
```

## 確立される開発フロー

### Claude → ユーザー(コード変更)
```
[Claude側]                          [ユーザー側]
 ZIP生成                              ZIP受信
   ↓                                   ↓
 kk-reader-update-{n}-{desc}.zip  →  Codespacesにドラッグ&ドロップ
                                       ↓
                                     unzip -o → commit → push
```

### ユーザー → Claude(状態共有)
```
[ユーザー側]                         [Claude側]
 python3 scripts/snapshot.py         スナップショット受信
   ↓                                   ↓
 kk-reader-snapshot-{時刻}.zip   →   STATE.json と source/ を確認
                                       ↓
                                     状況に応じた更新ZIPを生成
```

## スナップショットの取り方

```bash
python3 scripts/snapshot.py
```

実行すると、プロジェクトルートに `kk-reader-snapshot-{タイムスタンプ}.zip` が生成されます。
これをClaudeにアップロードすれば、現在の状態を完全に把握した上で対応できます。

### スナップショットの内容

- **STATE.json**: 全体状態の集計サマリ
  - git情報(現在のcommit、最近の履歴、未コミット変更)
  - フィード状態(成功/失敗の内訳、エラー分類、失敗フィード詳細)
  - 記事の集計(カテゴリ別、フィード別、経過時間別、直近サンプル)
- **source/**: 現在のソースコード一式
  - すべてのコードファイル(`.py`、`.html`、`.js`、`.css`、`.yml`)
  - `feeds.json`(フィードの状態管理用)
  - `subscriptions.opml`(購読リスト)
  - 各種マークダウン文書

### スナップショットに含まれないもの(意図的)

- **記事本文** (`articles.json` の `content_html`): プライバシーとサイズの観点で除外
- **既読・お気に入り情報**: ブラウザのlocalStorageに格納されており、サーバー側に存在しない
- **認証情報**: そもそも保存していないため、漏洩リスクなし

これらを除いても、コード改良に必要な情報は全て含まれます。

## いつスナップショットを送るか

以下の場面で送ってください。判断材料が揃うため、より精度の高い対応ができます。

1. **新機能を相談する時**: 現状のコードを踏まえた提案ができる
2. **不具合の報告**: エラーの背景にある状態が確認できる
3. **取得失敗の対処相談**: 失敗フィードのリストと分類が含まれている
4. **長期間ぶりの再開時**: コードがどこまで進んでいるか即把握できる
5. **大規模な改修前**: 安全な変更計画を立てられる

軽い質問(操作方法など)では不要です。コード変更や状態に依存する判断が必要な時のみで十分です。
